/**
*   Cabeceras de la heuristica.
*   Declaración de los elementos utilizados en
*   3piezas.c
*/

//#define N 6

/*  static int puzle_inicial[N][N]=
{
  {4, 0, 0, 0, 0, 3},
  {4, 0, 0, 0, 0, 3},
  {0, 1, 0, 0, 0, 3},
  {1, 1, 1, 4, 2, 0},
  {0, 1, 0, 2, 2, 2},
  {0, 0, 0, 0, 0, 0}
};


static int puzle_final[N][N]=
{
  {4, 0, 0, 0, 0, 0},
  {4, 0, 0, 0, 0, 0},
  {0, 0, 0, 0, 0, 0},
  {0, 1, 0, 4, 0, 3},
  {1, 1, 1, 2, 0, 3},
  {0, 1, 2, 2, 2, 3}
};

//Estructura de tipos donde se almacenarán los datos

typedef struct
{
  int celdas[N][N];
  int filA, colA, filB, colB, filC, colC;
} tEstado;

int heuristica(tEstado *s);

tEstado *estadoInicial();

//tEstado *crearEstado(int celdas[N][N]);

//void dispEstado(tEstado *estado);

*/

//#include "puzle.h"

#define N 2

#ifndef _tEstado_
#define _tEstado_
   typedef struct {
        int celdas[N][N];
        int fila[N*N], col[N*N];
   } tEstado;
#endif

int heuristica(tEstado *s);
