/**
*   Definición de la función heuristica
*/

//Sección de importación

#include <stdio.h>
#include <stdlib.h>
//#include "3piezas.h"
#include "puzle.h"


/*  tEstado *crearEstado(int celdas[N][N])
{
   tEstado *estado = (tEstado *) malloc(sizeof(tEstado));
   int i, j, ficha, aux;

   for (i=0;i<N;i++)
      for (j=0;j<N;j++)
      {
         ficha = celdas[i][j];
         estado -> celdas[i][j] = ficha;
         estado -> filA = celdas[i-1][j] == 1 && celdas[i+1][j] == 1;
         estado -> colA = celdas[i][j-1] == 1 && celdas[i][j+1] == 1;
         estado -> filB = celdas[i-1][j] == 2;
         estado -> colB = celdas[i][j-1] == 2 && celdas[i][j+1] == 2;
         estado -> filC = celdas[i-1][j] == 3 && celdas[i+1][j] == 3;
         aux = estado -> filC;
         estado -> colC = aux;
       }

   return estado;
}

void dispEstado(tEstado *estado)
{
   int i,j;

   for (i=0; i<N; i++)
   {
      for (j=0; j<N; j++)
         printf("%d",estado->celdas[i][j]);
      printf("\n");
   }
   printf("\n");

   //Traza
   printf("%d\n", estado -> filA);
   printf("%d\n", estado -> colA);
   printf("%d\n", estado -> filB);
   printf("%d\n", estado -> colB);
   printf("%d\n", estado -> filC);
   printf("%d\n", estado -> colC);
}

tEstado *estadoInicial()
{
   return crearEstado(puzle_inicial);
} */

int heuristica(tEstado *s)
{
  int cont, i, j;
  tEstado *final;
  final = estadoObjetivo();

  //Mal colocadas

  cont = 0;
  for (i = 0; i < N; i++)
  {
    if(s -> fila[i] != final -> fila[i] || s -> col != final -> col)
      cont++;
  }

  return cont;
}

int main()
{
  tEstado *estado;
  int cont;

  estado = estadoInicial();
  dispEstado(estado);

  //cont = heuristica(estado);

  //printf("%d" , cont);

  return 0;
}
