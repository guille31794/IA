/*******************************************/
/* 		    BUSQUEDA.H                     */
/*						                   */
/* Asignatura: Inteligencia Artificial     */
/* Grado en Ingenieria Informatica - UCA   */
/*******************************************/

int busqueda();

/**
*   Busca un estado dentro de una lista de elementos
*/

int buscaRepe(tEstado *s, Lista L1);
