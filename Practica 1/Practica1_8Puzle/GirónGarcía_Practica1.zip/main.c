#include <puzle.h>

int main() {
  
  return 0;
}
